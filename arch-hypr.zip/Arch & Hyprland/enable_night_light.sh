#!/bin/bash

clear

# Enable Night Light
redshift -O 3000K -r -P

# Disable Night Light
# redshift -O 6500K -r -P